<?php exit();?>
[2025-01-15 02:15:55] ERROR: <br>PHP warning : <em>Undefined property: Gcms\Config::$version</em> in <b>C:\xampp\htdocs\HTC-BORROWEQ-main\modules\index\controllers\index.php</b> on line <b>113</b> 
[2025-01-15 02:15:56] ERROR: <br>PHP warning : <em>Undefined property: Gcms\Config::$version</em> in <b>C:\xampp\htdocs\HTC-BORROWEQ-main\modules\index\controllers\index.php</b> on line <b>113</b> 
[2025-01-15 02:16:02] ERROR: <br>PHP warning : <em>Undefined property: Gcms\Config::$version</em> in <b>C:\xampp\htdocs\HTC-BORROWEQ-main\modules\index\controllers\index.php</b> on line <b>113</b> 
[2025-01-15 02:16:33] ERROR: <br>Exception : <em>Class "Borrow\Email\Model" not found</em> in <b>C:\xampp\htdocs\HTC-BORROWEQ-main\Kotchasan\Kotchasan.php</b> on line <b>76</b> 
[2025-01-15 02:18:03] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-15 02:19:02] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-15 02:19:30] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-15 02:23:19] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-15 02:23:54] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-15 02:25:13] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-17 22:34:41] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-17 22:34:57] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-17 22:35:09] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-17 23:41:31] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-17 23:45:50] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 00:04:50] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 00:09:12] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 09:11:59] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 09:43:13] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 09:45:07] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 16:32:03] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 16:32:50] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 16:34:19] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 
[2025-01-18 16:36:07] ERROR: <br>PHP warning : <em>Array to string conversion</em> in <b>C:\xampp\htdocs\borrow-main\Kotchasan\Database\PdoMysqlDriver.php</b> on line <b>125</b> 